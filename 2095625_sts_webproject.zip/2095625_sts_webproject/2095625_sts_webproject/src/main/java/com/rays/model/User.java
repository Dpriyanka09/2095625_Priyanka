package com.rays.model;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "user")
@Component
public class User {

	@Id   //Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO)   // 
	private Integer id;
	//@Column(name = "uname")
	private String userName;
	private String userPassword;
	private Integer userAge;
	private String userState;
	private String agree;
	
	@Lob
	private byte[] userPic;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(Integer id, String userName, String userPassword, Integer userAge, 
			String userState,String Agree ) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userState = userState;
		this.agree=Agree;
		
	}
	
	
	public User(Integer id, String userName, String userPassword, Integer userAge, String userState,
			String Agree ,byte[] userPic) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userState = userState;
		this.agree=Agree;
		this.userPic = userPic;
	}
	public Integer getId() {
		
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public Integer getUserAge() {
		return userAge;
	}
	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}
	public String getUserState() {
		return userState;
	}
	public void setUserState(String userState) {
		this.userState = userState;
		
	}
	
	
	public String getAgree() {
		return agree;
	}
	public void setAgree(String agree) {
		agree = agree;
	}
	public byte[] getUserPic() {
		return userPic;
	}
	public void setUserPic(byte[] userPic) {
		this.userPic = userPic;
	}
	public String getUserPicture() {
		return Base64.encodeBase64String(userPic);
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", userPassword=" + userPassword + ", userAge=" + userAge
				+ ", userState=" + userState +  ", agree=" + agree + ", userPic="
				+ Arrays.toString(userPic) + "]";
	}
}
