package com.rays.controller;

import org.springframework.stereotype.Controller;

@Controller
public class CustomerController {

}
