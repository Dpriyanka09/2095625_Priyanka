import java .util.Scanner;

public class Numbercheckmain {

	public static void main(String[] args) {
		
			
			Scanner scanner=new Scanner(System.in);
			Numbercheckmain numbercheck= new Numbercheckmain();
			Numbercheckmain.biggestNumber();
	}

}
