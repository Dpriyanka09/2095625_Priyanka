
public class Car extends MotorisedVehicle {
	public interface MotorisedVehicle extends IVehicle{
		public default void drive(){
			System.out.println(" The car is in brake mode");
		}
	}
	public static void drive(){
		System.out.println("Is in good condition");
	}
}


