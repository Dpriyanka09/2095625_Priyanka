
public abstract class Train implements IVehicle,IPublicTransport{
	public void turnLeft(){
		System.out.println("TurnLeft Side");
	}
	public void brake(){
		System.out.println("Apply Brake");
	}

}
