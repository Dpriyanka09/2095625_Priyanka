
public interface IPublicTransport {
	public void getNumberOfPeople();

}
