package com.cognizant;

public class classB extends classA{
	public void methodB()
	{
		System.out.println("method of classB");
	

}
}
