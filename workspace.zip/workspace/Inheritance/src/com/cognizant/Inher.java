package com.cognizant;

public class Inher {

	public static void main(String[] args) 
	{
		classB obj1=new classB();
		classC obj2=new classC();
		classD obj3=new classD();
		obj1.methodA();
		obj2.methodA();
		obj3.methodA();
		
		}

}
