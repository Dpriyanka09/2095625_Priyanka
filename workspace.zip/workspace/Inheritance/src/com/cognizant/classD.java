package com.cognizant;

public class classD extends classA {
	public void methodD()
	{
		System.out.println("method of class D");
	

}
}


