package com.cognizant;

public class classC extends classA{
	public void methodC()
	{
		System.out.println("method of class C");
	

}
}
