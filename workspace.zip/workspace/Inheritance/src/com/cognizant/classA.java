package com.cognizant;

public class classA {
	public void methodA()
	{
		System.out.println("method of classA");
	}

}
