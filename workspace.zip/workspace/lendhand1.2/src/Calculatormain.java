import java.util.Scanner;
public class Calculatormain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub;
		
		Scanner scanner =new Scanner(System.in);
		Calculator calculator=new Calculator();
		calculator.num1=scanner.nextInt();
		calculator.num2=scanner.nextInt();
		calculator.bitwiseAND();
		calculator.bitwiseOR();
		calculator.bitwiseNOT();
		calculator.bitwiseXOR();
		

	}

}
