
public class Square extends Shape{
	public void calculateArea(){
	int len=4;
	int bre=4;
	double Sarea=len*bre;
	System.out.println("Area of Square"+Sarea);
	
}
	public void setColor(){
		System.out.println("White");
	}
}
