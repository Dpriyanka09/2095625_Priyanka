
public class Circle extends Shape{
	 public void calculateArea(){
	 int r=5;
	 double Carea=3.14*r*r;
		 System.out.println("Area of circle is"+Carea);
	 }
		 
		 public void setColor(){
			 System.out.println("RED");
	 
	 
	 }		 
	     
}

