
public class AbstractDemo {

	public static void main(String[] args) {
		
          Shape s=new Circle();
          Shape sq=new Square();
          s.calculateArea();
          s.setColor();
          sq.calculateArea();
          sq.setColor();
	}

}
