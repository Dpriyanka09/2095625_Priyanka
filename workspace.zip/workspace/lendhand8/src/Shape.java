
public abstract class Shape {
	public abstract void calculateArea();
	public abstract void setColor();

}
