
 class MainProgram {

	public static void main(String[] args) {
		Employee employee=new Employee();
		
		System.out.println("The Id of the Employee is" + employee.empId);
		System.out.println("The Salary of the Employee is" + employee.empSalary);
		System.out.println("The Percentage of the Yax The Employee needs" + "to pay is" +employee.empTax);
		System.out.println("The Total Number of Working Days is " + employee.daysOfWork);
		employee.calculatePF();
		

	}

}
