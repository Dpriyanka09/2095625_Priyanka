import java.util.Date;
public class DateDemo {

	public static void main(String[] args) {
		Date d1=new Date(2012,01,15);
		Date d2=new Date(2011,07,15);
		int results=d1.compareTo(d2);
		if(results > 0){
			System.out.println("FIRST Date is after second");
		}
		else if(results <0){
			System.out.println("First date is before second");
	}
	else{
		System.out.println("Both dates are equal");
	}
	Date d=new Date();
	System.out.println("Today date is" +d.toString());
	
	}

}
