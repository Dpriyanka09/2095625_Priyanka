
public class StaticDemo {

		int a;
		static int b;
		public void staMet() {
			System.out.println("a = "+a+"\t b= "+b);
		}
		
		public static void hai() {
			System.out.println("From the Static Hai Method");
		}
	}


