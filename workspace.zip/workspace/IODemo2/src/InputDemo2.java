import java.io.BufferedInputStream;
		import java.io.FileInputStream;
		import java.io.IOException;
        public class InputDemo2 {

	public static void main(String[] args)throws IOException {
			// try with resource, AutoClosable interface implemented and close() called implicitly
						 
				try(FileInputStream inputStream = new FileInputStream("C:\\Users\\2095625\\workspace\\MethodDemo\\bin\\com\\rays");				
						BufferedInputStream bis = new BufferedInputStream(inputStream);) {
					
				int a=0;
				
				while((a=bis.read())!=-1) {
					System.out.print((char)a);
				}

				}catch (Exception e) {
					System.out.println("Error : "+e);
				}			
				
			}
}


