
public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome World......");

		Employee employee=new Employee();
		employee.id=101;
		employee.name="Priyanka";
		employee.salary=50000;
		employee.displayEmp();
	}

}
