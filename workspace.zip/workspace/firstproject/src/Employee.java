
public class Employee {
	int id;
	String name;
	double salary;
	
	void displayEmp() {
		System.out.println("Employee ID :"+id);
		System.out.println("Employee Name:"+name);
		System.out.println("Employee Salary:"+salary);
	}

}
