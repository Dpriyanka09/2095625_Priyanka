
public class dog extends animal{
	void whoAmI(){
		System.out.println("I m a Dog.");

	}
	}


