
public class snake extends animal{
	void whoAmI(){
		System.out.println("I m a Snake.");

	}
	}


