package lendhand7;

public class Runtimepolymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
