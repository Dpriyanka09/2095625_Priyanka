
public class Runtimepolymorphism {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		animal ref1=new animal();
		animal ref2=new dog();
		animal ref3=new cow();
		animal ref4=new snake();
		ref1.whoAmI();
		ref2.whoAmI();
		ref3.whoAmI();
		ref4.whoAmI();	
}
}
