
public class cow extends animal{
	void whoAmI(){
		System.out.println("I m a Cow.");

	}
	}



