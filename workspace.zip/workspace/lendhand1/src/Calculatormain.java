
public class Calculatormain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calculator calculator=new Calculator();
		calculator.num1=11;
		calculator.num2=17;
		calculator.addition();
		calculator.subtraction();
		calculator.printSmaller();

	}

}
