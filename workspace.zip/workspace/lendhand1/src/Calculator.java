
public class Calculator {
	int num1;
	int num2;
	
	void addition(){
		int num3=num1+num2;
		System.out.println("The Sum of the"+ "two numbers is:" +num3);}
		
	void subtraction(){
		int num3 = num1 - num2;
		System.out.println("The difference between the"+"Two numbers is :"+num3);}

    void printSmaller(){
    	int num3=(num1<num2) ? num1:num2;
    	System.out.println("The Smallest of the" +"Two Number is" +num3);}
    
			
		
	}


