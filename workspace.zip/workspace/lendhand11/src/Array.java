
public class Array {

	public static void main(String[] args) {
		ArrayDemo arrayDemo= new ArrayDemo();
		arrayDemo.StoreNumbers();
		arrayDemo.PrintEvenNumber();

	}

}
