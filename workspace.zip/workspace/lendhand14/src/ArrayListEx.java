import java.awt.List;
import java.util.ArrayList;

public class ArrayListEx {
	
	public List getCountryList(String c1,String c2,String c3,String c4,String c5){
		ArrayList countryList=new ArrayList();
		countryList.add(c1);
		countryList.add(c2);
		countryList.add(c3);
		countryList.add(c4);
		countryList.add(c5);
		return countryList;
	}

   public List get1To10(){
	   List numList=new ArrayList();
	   for (int i=1;i<=10;i++){
		   numList.add(i);
	   }
	   return numList;
   }
   public List get1To15(List numList){
	   List numList2=new ArrayList();
	   numList2.addAll(numList);
	   for (int i=11;i<=15;i++){
		   numList2.add(i);
	   }
	   return numList2;
   }
	   }
   
   


