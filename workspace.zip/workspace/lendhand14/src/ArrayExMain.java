import java.awt.List;
public class ArrayExMain {

	public static void main(String[] args) {
		ArrayListEx ex1=new ArrayListEx();
		System.out.println(ex1.getCountryList("India","Australia ", "England", "South Africa", "New Zealand"));
		List numList = ex1.get1To10();
		System.out.println(numList);
		System.out.println(ex1.get1To15(numList));
	}
}
