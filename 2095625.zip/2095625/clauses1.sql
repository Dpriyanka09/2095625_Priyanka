create database day4;
use day4;                                                               /* handson clauses1 */
use day1;
select* from associate_status;
select sum(Aid),sdate from associate_status
group by sdate;                                                /*problem 1*/
select sum(Aid),sdate from associate_status
where mid='clr'                                                   /*problem 2*/
group by sdate;
select sum(Aid),sdate from associate_status
where mid='clr'
group by sdate                                                    /*problem 3*/
having sum(Aid)>2;
select* from module_info;
select m_id,m_name,mdur,minfra from module_info
order by mdur;                                                    /*problem 4*/
use day1;
create table associate_info(Aid varchar(20) ,Asal varchar(7),Aname varchar(30),Aloc varchar(30)
,Atrac varchar(15), Aqual varchar(100),Amail varchar(100),Apwd varchar(20));
insert into associate_info values('A001','Miss.','GAYATHRI NARAYANAN','Gurgaon','Java','BachelorTechnology','Gayathri.Narayanan@hp.com','tne1@123'),
('A002','Mrs.','RADHIKA MOHAN','Kerala','Java','BachelorEngineering Information Technology','Radhika.Mohan@cognizant.com','tne2@123'),
('A003','Mr.','KISHORE SRINIVAS','Chennai','Java','Bachelor Engineering Computers','Kishore.Srinivas@ibm.com','tne3@123'),
('A004','Mr.','ANAND RANGANATHAN','Mumbai','DotNet','MasterComputer Applications','Anand.Ranganathan@finolex.com','tne4@123'),
('A005','Miss.','LEELA MENON','Kerala','Mainframe','BachelorEngineering Information Technology','Leela.Menon@microsoft.com','tne5@123'),
('A006','Mrs.','ARTI KRISHNAN','Pune','Testing','MasterComputer Applications','Arti.Krishnan@cognizant.com','tne6@123'),
('A007','Mr.','PRABHAKAR SHUNMUGHAM','Mumbai','Java','BachelorTechnology','Prabhakar
.Shunmugham@honda.com','tne7@123');
select a.Aname,m.m_id,m.m_name,m.minfra from associate_info a,module_info m
order by m.minfra desc;                                          /*problem 5*/
