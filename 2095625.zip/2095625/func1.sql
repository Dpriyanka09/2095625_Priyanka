use day1;
select* from module_info;                                              /* handson function1*/
drop table module_info;
create table module_info(m_id varchar(20),m_name varchar(40),mdur int,minfra float);
insert into Module_info values('O10SQL','Oracle 10g SQL' ,16,300.123),('O10PLSQL','Oracle 10g PL/ SQL' ,16,65.34),('J2SE','Core Java SE 1.6',288,20.00),
('J2EE','Advanced Java EE 1.6',80,306.9),('JAVAFX','JavaFX 2.1',80,80.653),('DOTNT4','.Net Framework 4.0' ,50,3567.9),('SQL2008','MS SQl Server 2008',120,23.9876),
('MSBI08','MS BI Studio 2008',158,21.34),('SHRPNT','MS Share Point' ,80,345.987625),('ANDRD4','Android 4.0',200,400),('EM001','Instructor',0,0.0),
('EM002','Course Material',0,0),('EM003','Learning Effectiveness',0,876.9),('EM004','Environment',0,800.45),('EM005','Job Impact',0,0.0),
('TM001','Attendees',0,23),('TM002','Course Material',0,0),('TM003','Environment',0,0);
select module_info.m_name,
ROUND((minfra),2)
from module_info;
select concat(upper(left(m_name,1)),
lower(substring(m_name,2)))
from module_info;
select * from associate_status;
select mid ,
to_days(current_date)-
to_days(sdate) 
from associate_status;
select concat(m_name,m_id)from module_info;
select upper(m_name) from module_info;
select substr(m_name,1,3) from module_info;
select avg(ifnull(minfra,0)) from module_info;
select* from trainer_info;
select 100000+cast(tid as decimal) from trainer_info;
use day1;
select concat('the base fees amount for the mname is',CINFO.m_name,cast(FEESINFO.BASE_FEES as decimal))
from trainer_info CINFO,minfra ;
select concat('The Base Fees Amount for the module name',module_info.M_Name, 
cast(module_info.Base_Fees as decimal)) from module_info;
where CINFO.mid=minfra=mid;
select count(*) from module_info;
select sum(minfra) from module_info;
select min(minfra) ,max(minfra) from module_info;