use day12;
select* from stu_info;                                                                          /*Operators2 Handson*/
select regno,sname,branch,con,dob,doj,address from stu_info where email is not null;
select regno,marks_no from stu_marks where marks_no>50;
use day12;
select regno,sname from stu_info union
select 
subject_code ,subject_name from Subject_Master union
select sem_no ,marks_no from stu_marks where marks_no>50;
select regno,cgpa,scholarship from stu_result order by cgpa desc;
select regno,sname from stu_info union
select marks_no from stu_marks union
select weightage_number from Subject_master;
use day12;
select* from stu_info;
select sname from stu_info where sname like'M%' order by sname;
select sname,regno from  stu_info where email  is not null 
union
select sem_no,marks_no from stu_marks ;
select sname from stu_info where sname like '%on' order by sname; /*problem12*/

