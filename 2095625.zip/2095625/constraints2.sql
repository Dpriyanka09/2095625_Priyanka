use day3;
create table student_info(regno varchar(30) primary key ,stuname varchar(30) not null,branch varchar(30),cont varchar(30),
DOB varchar(30),DOJ varchar(30));
create table subject_master(subcode varchar(20) primary key,sname varchar(20) not null,weightage int not null);
create table student_marks(regno varchar(20),constraint fk_regno foreign key(regno) references student_info(regno),
subcode varchar(20),constraint fk_subcode foreign key(subcode) references subject_master(subcode),sem int not null,marks int );
create table Student_result(regno varchar(30),constraint fk_Student_regno foreign key(regno) references student_info(regno),
sem int not null,GPA int not null,Scholarship varchar(3));
alter table subject_master modify sname varchar(20) not null unique;
alter table student_info modify cont varchar(30)  unique;
alter table student_info  add check(DOB < DOJ);
alter table student_marks add check(marks<=100);
alter table student_result add check(GPA<=10);
alter table student_result add check (Scholarship='Y' or Scholarship='N');
