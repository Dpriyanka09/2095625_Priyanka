use day1;
select * from trainer_info;
select tmail from trainer_info where tmail not like '%@%';
select tid,tname,ttrac, tloc from trainer_info where texp>4;
select m_name from module_info where mdur>200;
select tid,tname from trainer_info where tqual not in('Bachelor of Technology');
select tid ,sal ,tname ,tloc , tqual ,texp ,tmail ,tpwd from  trainer_info;
SET SQL_SAFE_UPDATES=0;
delete from trainer_info where  tid='F001';
select* from trainer_info;
insert into trainer_info values('F001','Mr.','PANKAJ GHOSH','Pune','Java','Bachelor of Technology' ,12,'PankajGhosh@alliance.com' ,'fac1@123');
select tid,tname from trainer_info where tqual <>('Bachelor of Technology');
select m_id m_name from module_info where mdur between 200 and 300;
select tid,tname from trainer_info where tname like'M%';
use day1;
select tid,tname from trainer_info where substring_index(tname," ",1) like'O%';
select m_name from module_info where m_name is not null;


