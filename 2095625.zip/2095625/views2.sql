use day12;
create view student_cgpa as select s.regno,s.sname ,r.semno,r.cgpa from stu_info s 
join stu_result r where s.regno=r.regno;                                                     /*problem1*/
select sname, regno, semno, cgpa from student_cgpa
where cgpa>5;                                                                                /*problem2*/
create view student_avg_cgpa as select s.regno,s.sname ,r.semno,r.cgpa from stu_info s 
join stu_result r where (select avg(r.cgpa)from stu_result r);                               /*problem3*/
select sname, regno, semno, avg(cgpa)from stu_avg_cgpa where cgpa>7;                         /*problem4*/
create index stu_mark_sem on stu_marks(sem_no);
alter table stu_marks drop index stu_mark_sem;                                               /*problem5*/
create unique index stu_info_email on stu_info(email);                                       /*problem6*/
