use day12;
select s.regno,s.sname from stu_info s inner join stu_marks  m  on s.regno=m.regno        /*problem1*/
 where m.marks_no in(select max(marks_no) from stu_marks  m);
 select s.regno,s.sname from stu_info s inner join stu_marks m on s.regno=m.regno             /*problem2*/
 where m.marks_no in(select max(marks_no)from stu_marks  m where m.sub_code='EI05IP');
 select s.regno ,s.sname from stu_info s inner join stu_marks m on s.regno=m.regno                               /*problem3*/
 where( m.marks_no = (select marks_no from stu_marks  m where sub_code='EI05IP' order by marks_no desc limit 1,1)and sub_code='EI05IP');
 select regno from stu_marks
where marks_no > (select avg(marks_no) from stu_marks where sub_code='EI05IP');                  /*problem4*/
 