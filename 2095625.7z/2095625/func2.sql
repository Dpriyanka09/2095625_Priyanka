use day12;
select upper(concat(sname,branch)) from stu_info;
select lower(concat(subject_code, subject_name, weightage_number)) from subject_master;
select date_format(dob,'%d/%m/%Y') from stu_info;
select date_format(dob,'%M %d,%Y') from stu_info;
select regno,max(marks_no) from stu_marks;