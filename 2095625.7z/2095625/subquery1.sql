use day1;
select * from associate_info where aname in(select Aname from associate_info where Aname like'%i%');     /*problem1*/
select * from associate_info where aname in(select Aname from associate_info where Aname not like'%i%');     /*problem2*/
select * from trainer_info;
select tid from associate_status 
 where mid in (select mid from associate_status where mid='J2EE');                                         /*problem3*/
 CREATE TABLE Trainer_Info_Sabbatical(Trainer_Id VARCHAR(20) PRIMARY KEY,Salutation VARCHAR(7) NOT NULL,
Trainer_Name VARCHAR(30) NOT NULL,Trainer_Location VARCHAR(30) NOT NULL,Trainer_Track VARCHAR(15) NOT NULL,
Trainer_Qualification VARCHAR(100) NOT NULL,Trainer_Experiance int ,Trainer_Email VARCHAR(100) NOT NULL,
Trainer_Password VARCHAR(20) NOT NULL);
insert into Trainer_Info_Sabbatical values ('F011','Mr.','Shyju K', 'Kochi','Java','Bachelor of Technology',9,'shyju@alliance.com','fac11@123');
insert into Trainer_Info_Sabbatical values ('F012','Mr.','Raviraj Kumar', 'Kochi','Java','Bachelor of Technology',8,'raviarajkumar@alliance.com','fac12@123');
insert into Trainer_Info_Sabbatical values ('F013','Mr.','Suresh Babu N', 'Mumbai','Testing','Bachelor of Technology',19,'sureshbabun@alliance.com','fac13@123');
                                      /*problem4*/
SET SQL_SAFE_UPDATES=0;
 update  Trainer_Info set tloc='Kochi' where Texp= 
 (select Texp from Trainer_Info_Sabbatical where Trainer_Experiance > 10);  /*problem5*/    
 delete from Trainer_Info where Texp =
(select Texp from Trainer_Info_Sabbatical where Trainer_Experiance > 12);  /*problem6*/ 
 select tis.* 
 from Trainer_Info_Sabbatical as tis 
 where Trainer_Id=(select tid 
                   from trainer_info as ti where ti.tid=tis.Trainer_Id);  /*problem7*/
