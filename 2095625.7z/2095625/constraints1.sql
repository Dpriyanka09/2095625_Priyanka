
use day2;
create table Trainer_info(Tid int ,sal varchar(20), Tname varchar(20), loc varchar(20), track varchar(20), qua varchar(20),exp int,Temail varchar(200),Tpass varchar(20), constraint Tid_pk primary key(Tid));
drop table t_info;
drop table Trainer_info;
create table T_info(Tid int primary key,sal varchar(20), Tname varchar(20), loc varchar(20), track varchar(20), qua varchar(20),exp int,Temail varchar(200),Tpass varchar(20), constraint Tid_chk Check(Tid like 'F%'));
create table batch_info(Bid varchar(20) not null primary key check(Bid like 'B%'),Bown varchar(20)not null,BBu varchar(20)not null);
create table Module_info(Mid varchar(20)not null primary key, Mname varchar(20)not null, Mdur int not null);
SELECT
Mid, UPPER(Mid)
FROM Module_info
WHERE
BINARY Mid <> BINARY UPPER(Mid);
create table A_info(Aid varchar(20) not null primary key check(Aid like 'A%'),Asal varchar(20)not null,Aname varchar(20)not null,Aloc varchar(20)not null,Atrack varchar(20)not null,Aqua varchar(20)not null,Aem varchar(250)not null,Apas varchar(20)not null);
create table Ques(Qid varchar(20) not null primary key check(Qid like 'Q%'), Mid varchar(20), foreign key(Mid) references Module_info(Mid), Qtext varchar(200)not null);
create table A_status(Aid varchar(20)not null,foreign key(Aid) references A_info(Aid),
Mid varchar(20)not null, foreign key(Mid) references Module_info(Mid),
Bid varchar(20)not null, foreign key(Bid) references batch_info(Bid),
Tid int not null, foreign key(Tid) references t_info(Tid),
sdate date,edate date, Afb varchar(20),Tfb varchar(20));
create table T_fb(Tid int not null, foreign key(Tid) references t_info(Tid),
Qid varchar(20)not null, foreign key(Qid) references Ques(Qid),
Bid varchar(20)not null, foreign key(Bid) references batch_info(Bid),
Mid varchar(20)not null, foreign key(Mid) references Module_info(Mid),
Mrate int not null);
create table A_fb(Aid varchar(20)not null,foreign key(Aid) references A_info(Aid),
Qid varchar(20)not null, foreign key(Qid) references Ques(Qid),
Mid varchar(20)not null, foreign key(Mid) references Module_info(Mid),
Arate int not null);
create table product(Pid int primary key, Pname varchar(20), Pprice int not null);
create table user_(user_id varchar(10) primary key,
Pid int,
constraint fk_us_Pid
foreign key(Pid) references product(Pid),
user_name varchar(20));
insert into product values(1,'A Dongle',290),(2,'B Dongle',1250);
insert into product values(3,'C Dongle',0);
select * from product;
insert into user_ values('U001',1,'Ramesh'),('U002',11,'Mahesh');