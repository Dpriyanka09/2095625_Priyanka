use day12;
select s.sname,m.sub_code from stu_info s 
cross join stu_marks m;
select s.regno,s.sname,m.regno,m.sub_code ,m.marks_no from stu_info s 
inner join stu_marks m on  s.regno=m.regno where m.marks_no>=65;
select s.regno,s.sname,r.regno,max(r.cgpa )from stu_info s
inner join stu_result r on s.regno=r.regno where r.cgpa;
create table backup_sinfo(Reg_number varchar(20) primary key, Student_Name Varchar(30) not null,
Branch Varchar(20),Contact_Number Varchar(20),Date_of_Birth Date not null,
Date_of_Joining Date , Address Varchar(250), Email_id Varchar(250));
drop table backup_sinfo;
create table backup_sinfo(Reg_number varchar(20) primary key, Student_Name Varchar(30) not null,
Branch Varchar(20),Contact_Number Varchar(20),Date_of_Birth Date not null,
Date_of_Joining Date , Address Varchar(250), Email_id Varchar(250));
insert into backup_sinfo values('MC101301', 'James' ,'MCA' ,'9714589787', '1984-01-12',' 2010-07-08','No 10,South Block','Nivea james.mca@yahoo.com'),
('BEC111402 ','Manio',' ECE', '8912457875', '1983-02-23', '2011-06-25' ,'8/12,Park View','Sieera manioma@gmail.com'),
('BEEI101204', 'Mike',' EI', '8974567897', '1983-02-10', '2010-08-25', 'Cross villa,NY', 'mike.james@ymail.com'),
('MB111305', 'Paulson',' MBA','8547986123', '1984-10-13', '2010-08-08', 'Lake view','NJ paul.son@rediffmail.com');
use day4;
insert into student_info values('MC101','Jam','MA','971458787','1984-01-22','2010-07-07' ,'Block,Nivea','s.mca@yahoo.com',5),
('BEC11','nia ','EC',' 8912457878', '1983-02-13', '2011-01-05', 'Park View,Sieera','nia@gmail.com',7),
('BEEI','Mik','rEI',' 8974567197', '1983-02-17', '2010-08-05 ','villa,NY' ,'miks@ymail.com',7),
('MB11', 'Paul', 'MbA', '8547986193', '1984-12-03', '2010-08-18', 'LakeNJ ','paul@rediffmail.com',7);
alter table student_info  add( age int);
insert into student_info values('MC101','Jam','MA','971458787','1984-01-22','2010-07-07' ,'Block,Nivea','s.mca@yahoo.com',5),
('BEC11','nia ','EC',' 8912457878', '1983-02-13', '2011-01-05', 'Park View,Sieera','nia@gmail.com',7),
('BEEI','Mik','rEI',' 8974567197', '1983-02-17', '2010-08-05 ','villa,NY' ,'miks@ymail.com',7),
('MB11', 'Paul', 'MbA', '8547986193', '1984-12-03', '2010-08-18', 'LakeNJ ','paul@rediffmail.com',7);
select s.regno,s.sname,s.branch,s.Contact,s.dob,s.doj,s.address,s.email_Id,
m.reg_number,m.student_name,m.branch,m.Contact_Number,m.Date_of_Birth,m.Date_of_Joining,m.address,m.Email_id
from student_info s right outer join backup_sinfo m
on s.regno=m.Reg_Number;
select s.regno,s.sname,s.branch,s.contact,s.Dob,s.Doj,s.address,s.Email_id,
m.reg_number,m.student_name,m.branch,m.Contact_Number,m.Date_of_Birth,m.Date_of_Joining,m.address,m.Email_id
from student_info s left outer join backup_sinfo m
on s.Regno=m.Reg_Number;
