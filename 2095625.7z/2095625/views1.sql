use day1;
select* from associate_status;
create view  view_status
as select Aid,tid,bid from associate_status;                       /*problem1*/
create view view_status_details
 as select aid,tid,bid from associate_status where bid='B004';                  /*problem2*/ 
 drop view view_status_details;                                                 /*problem3*/
 create index index_associate on associate_info(Aname);
 create unique index index_associate_details on associate_info(Aname);                     /*problem4*/
 alter table associate_info drop index index_associate_details;                             /*problem5*/
 create view view_assoc as select aid,bid,tid from associate_status where bid='B004'
 order by aid with local check option;                                                     /*problem6*/
 create view view_assoc_detail as select aid,bid,tid from associate_status where bid='B004'
 order by aid with cascaded check option;                                                    /*problem7*/