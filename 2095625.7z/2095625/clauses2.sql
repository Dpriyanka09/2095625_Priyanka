use day4;
use day12;                                                                                   /*Clauses handson2 */
select* from  stu_info;
select s.sname,s.regno,r.cgpa from stu_info s,stu_result r 
order by r.cgpa desc;                                                                                 /*problem 1*/
select regno,sname ,branch,dob,doj,address,email,con from stu_info order by sname asc;                  /*problem 2*/
select regno,sname ,branch,dob,doj,address,email,con from stu_info order by dob asc;                       /*problem 3*/ 
select s.regno,s.sname,r.semno,r.cgpa from stu_info s,stu_result r
order by r.cgpa desc;                                                                                        /*problem 4*/
select regno,cgpa,scholarship from stu_result order by scholarship not like 'Y';                              /*problem 5 and 6*/
select s.regno,s.sname ,s.branch,s.dob,s.doj,s.address,s.email,s.con ,r.semno,max(r.cgpa) from stu_info s,stu_result r 
group by r.semno ;                                                                                             /*problem 7*/
select s.regno,s.sname ,s.branch,s.dob,s.doj,s.address,s.email,s.con ,r.semno,min(r.cgpa) from stu_info s,stu_result r 
group by r.semno ;                                                                                             /*problem 8*/
                                                                                            
                                                                        



